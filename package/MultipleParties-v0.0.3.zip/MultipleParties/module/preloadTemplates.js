export const preloadTemplates = async function () {
    const templatePaths = [
    // Add paths to "modules/MultipleParties/templates"
    ];
    return loadTemplates(templatePaths);
};
